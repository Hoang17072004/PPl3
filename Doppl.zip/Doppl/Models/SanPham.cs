﻿using System;
using System.Collections.Generic;

namespace Doppl.Models
{
    public partial class SanPham
    {
        public SanPham()
        {
            ChiTietGioHangs = new HashSet<ChiTietGioHang>();
            ChiTietHoaDons = new HashSet<ChiTietHoaDon>();
            ChiTietKhuyenMais = new HashSet<ChiTietKhuyenMai>();
            LoHangs = new HashSet<LoHang>();
            QuanLyChiDinhs = new HashSet<QuanLyChiDinh>();
            QuanLyDoiTuongs = new HashSet<QuanLyDoiTuong>();
            QuanLyHinhAnhs = new HashSet<QuanLyHinhAnh>();
        }

        public int Id { get; set; }
        public int? IddonViTinh { get; set; }
        public int? IdphanLoai { get; set; }
        public int? IddangBaoChe { get; set; }
        public string? QuyCach { get; set; }
        public int? IdmuiVi { get; set; }
        public int? IdthuongHieu { get; set; }
        public string? ThanhPhan { get; set; }
        public string? MoTaNgan { get; set; }
        public string? SoDangKy { get; set; }
        public string? MoTaCuThe { get; set; }
        public string? CongDung { get; set; }
        public string? CachDung { get; set; }
        public string? TacDungPhu { get; set; }
        public string? LuuY { get; set; }
        public string? BaoQuan { get; set; }
        public int? IdloaiDa { get; set; }
        public string? Ten { get; set; }
        public string? HinhAnhChinh { get; set; }

        public virtual DangBaoChe? IddangBaoCheNavigation { get; set; }
        public virtual DonViTinh? IddonViTinhNavigation { get; set; }
        public virtual LoaiDum? IdloaiDaNavigation { get; set; }
        public virtual MuiVi? IdmuiViNavigation { get; set; }
        public virtual PhanLoai? IdphanLoaiNavigation { get; set; }
        public virtual ThuongHieu? IdthuongHieuNavigation { get; set; }
        public virtual ICollection<ChiTietGioHang> ChiTietGioHangs { get; set; }
        public virtual ICollection<ChiTietHoaDon> ChiTietHoaDons { get; set; }
        public virtual ICollection<ChiTietKhuyenMai> ChiTietKhuyenMais { get; set; }
        public virtual ICollection<LoHang> LoHangs { get; set; }
        public virtual ICollection<QuanLyChiDinh> QuanLyChiDinhs { get; set; }
        public virtual ICollection<QuanLyDoiTuong> QuanLyDoiTuongs { get; set; }
        public virtual ICollection<QuanLyHinhAnh> QuanLyHinhAnhs { get; set; }
    }
}
