﻿using System;
using System.Collections.Generic;

namespace Doppl.Models
{
    public partial class QuanLyChiDinh
    {
        public int? IdsanPham { get; set; }
        public int? IdchiDinh { get; set; }
        public int Id { get; set; }

        public virtual ChiDinh? IdchiDinhNavigation { get; set; }
        public virtual SanPham? IdsanPhamNavigation { get; set; }
    }
}
