﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Doppl.Models
{
    public partial class QuanLyThuocContext : DbContext
    {
        public QuanLyThuocContext()
        {
        }

        public QuanLyThuocContext(DbContextOptions<QuanLyThuocContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Admin> Admins { get; set; } = null!;
        public virtual DbSet<ChiDinh> ChiDinhs { get; set; } = null!;
        public virtual DbSet<ChiTietGioHang> ChiTietGioHangs { get; set; } = null!;
        public virtual DbSet<ChiTietHoaDon> ChiTietHoaDons { get; set; } = null!;
        public virtual DbSet<ChiTietKhuyenMai> ChiTietKhuyenMais { get; set; } = null!;
        public virtual DbSet<ChiTietNhapHang> ChiTietNhapHangs { get; set; } = null!;
        public virtual DbSet<DangBaoChe> DangBaoChes { get; set; } = null!;
        public virtual DbSet<DanhMuc> DanhMucs { get; set; } = null!;
        public virtual DbSet<DoiTuong> DoiTuongs { get; set; } = null!;
        public virtual DbSet<DonViTinh> DonViTinhs { get; set; } = null!;
        public virtual DbSet<GioHang> GioHangs { get; set; } = null!;
        public virtual DbSet<HoaDon> HoaDons { get; set; } = null!;
        public virtual DbSet<KhachHang> KhachHangs { get; set; } = null!;
        public virtual DbSet<KhuyenMai> KhuyenMais { get; set; } = null!;
        public virtual DbSet<LoHang> LoHangs { get; set; } = null!;
        public virtual DbSet<LoaiDum> LoaiDa { get; set; } = null!;
        public virtual DbSet<MuiVi> MuiVis { get; set; } = null!;
        public virtual DbSet<NhanVien> NhanViens { get; set; } = null!;
        public virtual DbSet<NhapHang> NhapHangs { get; set; } = null!;
        public virtual DbSet<Nuoc> Nuocs { get; set; } = null!;
        public virtual DbSet<PhanLoai> PhanLoais { get; set; } = null!;
        public virtual DbSet<QuanLyChiDinh> QuanLyChiDinhs { get; set; } = null!;
        public virtual DbSet<QuanLyDoiTuong> QuanLyDoiTuongs { get; set; } = null!;
        public virtual DbSet<QuanLyHinhAnh> QuanLyHinhAnhs { get; set; } = null!;
        public virtual DbSet<SanPham> SanPhams { get; set; } = null!;
        public virtual DbSet<ThuongHieu> ThuongHieus { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Data Source=DESKTOP-37IG69P\\SQLEXPRESS;Initial Catalog=QuanLyThuoc;Integrated Security=True;Persist Security Info=False;Pooling=False;Multiple Active Result Sets=True;Encrypt=False;Trust Server Certificate=False;Command Timeout=0");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Admin>(entity =>
            {
                entity.ToTable("Admin");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.DiaChi).HasMaxLength(200);

                entity.Property(e => e.Email)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.MatKhau)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.NgaySinh).HasColumnType("date");

                entity.Property(e => e.SoDienThoai)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Ten).HasMaxLength(50);

                entity.Property(e => e.TenDangNhap)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ChiDinh>(entity =>
            {
                entity.ToTable("ChiDinh");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Ten).HasMaxLength(100);
            });

            modelBuilder.Entity<ChiTietGioHang>(entity =>
            {
                entity.ToTable("ChiTietGioHang");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IdgioHang).HasColumnName("IDGioHang");

                entity.Property(e => e.IdsanPham).HasColumnName("IDSanPham");

                entity.HasOne(d => d.IdgioHangNavigation)
                    .WithMany(p => p.ChiTietGioHangs)
                    .HasForeignKey(d => d.IdgioHang)
                    .HasConstraintName("FK__ChiTietGi__IDGio__3B40CD36");

                entity.HasOne(d => d.IdsanPhamNavigation)
                    .WithMany(p => p.ChiTietGioHangs)
                    .HasForeignKey(d => d.IdsanPham)
                    .HasConstraintName("FK__ChiTietGi__IDSan__3C34F16F");
            });

            modelBuilder.Entity<ChiTietHoaDon>(entity =>
            {
                entity.ToTable("ChiTietHoaDon");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IdhoaDon).HasColumnName("IDHoaDon");

                entity.Property(e => e.IdsanPham).HasColumnName("IDSanPham");

                entity.HasOne(d => d.IdhoaDonNavigation)
                    .WithMany(p => p.ChiTietHoaDons)
                    .HasForeignKey(d => d.IdhoaDon)
                    .HasConstraintName("FK__ChiTietHo__IDHoa__76969D2E");

                entity.HasOne(d => d.IdsanPhamNavigation)
                    .WithMany(p => p.ChiTietHoaDons)
                    .HasForeignKey(d => d.IdsanPham)
                    .HasConstraintName("FK__ChiTietHo__IDSan__3D2915A8");
            });

            modelBuilder.Entity<ChiTietKhuyenMai>(entity =>
            {
                entity.ToTable("ChiTietKhuyenMai");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IdkhuyenMai).HasColumnName("IDKhuyenMai");

                entity.Property(e => e.IdsanPham).HasColumnName("IDSanPham");

                entity.HasOne(d => d.IdkhuyenMaiNavigation)
                    .WithMany(p => p.ChiTietKhuyenMais)
                    .HasForeignKey(d => d.IdkhuyenMai)
                    .HasConstraintName("FK__CTKM__IDKhuyenMa__2DE6D218");

                entity.HasOne(d => d.IdsanPhamNavigation)
                    .WithMany(p => p.ChiTietKhuyenMais)
                    .HasForeignKey(d => d.IdsanPham)
                    .HasConstraintName("FK__CTKM__IDSanPham__2EDAF651");
            });

            modelBuilder.Entity<ChiTietNhapHang>(entity =>
            {
                entity.ToTable("ChiTietNhapHang");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IdloHang).HasColumnName("IDLoHang");

                entity.Property(e => e.IdnhapHang).HasColumnName("IDNhapHang");

                entity.HasOne(d => d.IdloHangNavigation)
                    .WithMany(p => p.ChiTietNhapHangs)
                    .HasForeignKey(d => d.IdloHang)
                    .HasConstraintName("FK_ChiTietNhapHang_LoHang");

                entity.HasOne(d => d.IdnhapHangNavigation)
                    .WithMany(p => p.ChiTietNhapHangs)
                    .HasForeignKey(d => d.IdnhapHang)
                    .HasConstraintName("FK__ChiTietNh__IDNha__7E37BEF6");
            });

            modelBuilder.Entity<DangBaoChe>(entity =>
            {
                entity.ToTable("DangBaoChe");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Ten).HasMaxLength(100);
            });

            modelBuilder.Entity<DanhMuc>(entity =>
            {
                entity.ToTable("DanhMuc");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.LinkImage)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Ten).HasMaxLength(100);
            });

            modelBuilder.Entity<DoiTuong>(entity =>
            {
                entity.ToTable("DoiTuong");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Ten).HasMaxLength(100);
            });

            modelBuilder.Entity<DonViTinh>(entity =>
            {
                entity.ToTable("DonViTinh");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Ten).HasMaxLength(100);
            });

            modelBuilder.Entity<GioHang>(entity =>
            {
                entity.ToTable("GioHang");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IdkhachHang).HasColumnName("IDKhachHang");

                entity.HasOne(d => d.IdkhachHangNavigation)
                    .WithMany(p => p.GioHangs)
                    .HasForeignKey(d => d.IdkhachHang)
                    .HasConstraintName("FK__GioHang__IDKhach__71D1E811");
            });

            modelBuilder.Entity<HoaDon>(entity =>
            {
                entity.ToTable("HoaDon");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.GiamGiaTrucTiep).HasColumnType("money");

                entity.Property(e => e.IdgioHang).HasColumnName("IDGioHang");

                entity.Property(e => e.Ngay).HasColumnType("datetime");

                entity.Property(e => e.TamTinh).HasColumnType("money");

                entity.Property(e => e.TietKiem).HasColumnType("money");

                entity.Property(e => e.TongTien).HasColumnType("money");

                entity.Property(e => e.TrangThai).HasMaxLength(100);

                entity.HasOne(d => d.IdgioHangNavigation)
                    .WithMany(p => p.HoaDons)
                    .HasForeignKey(d => d.IdgioHang)
                    .HasConstraintName("FK__HoaDon__IDGioHan__4D5F7D71");
            });

            modelBuilder.Entity<KhachHang>(entity =>
            {
                entity.ToTable("KhachHang");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.DiaChi).HasMaxLength(200);

                entity.Property(e => e.MatKhau)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.NgaySinh).HasColumnType("date");

                entity.Property(e => e.SoDienThoai)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Ten).HasMaxLength(100);

                entity.Property(e => e.TenDangNhap)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<KhuyenMai>(entity =>
            {
                entity.ToTable("KhuyenMai");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Mota).HasMaxLength(1000);

                entity.Property(e => e.NgayBatDau).HasColumnType("date");

                entity.Property(e => e.NgayKetThuc).HasColumnType("date");

                entity.Property(e => e.Ten).HasMaxLength(200);
            });

            modelBuilder.Entity<LoHang>(entity =>
            {
                entity.ToTable("LoHang");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.GiaBan).HasColumnType("money");

                entity.Property(e => e.GiaVon).HasColumnType("money");

                entity.Property(e => e.IdsanPham).HasColumnName("IDSanPham");

                entity.Property(e => e.NgayHetHan).HasColumnType("date");

                entity.Property(e => e.NgaySanXuat).HasColumnType("date");

                entity.HasOne(d => d.IdsanPhamNavigation)
                    .WithMany(p => p.LoHangs)
                    .HasForeignKey(d => d.IdsanPham)
                    .HasConstraintName("FK__LoHang__IDSanPha__29221CFB");
            });

            modelBuilder.Entity<LoaiDum>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Ten).HasMaxLength(100);
            });

            modelBuilder.Entity<MuiVi>(entity =>
            {
                entity.ToTable("MuiVi");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Ten).HasMaxLength(100);
            });

            modelBuilder.Entity<NhanVien>(entity =>
            {
                entity.ToTable("NhanVien");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.DiaChi).HasMaxLength(200);

                entity.Property(e => e.MatKhau)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.NgaySinh).HasColumnType("date");

                entity.Property(e => e.SoDienThoai)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Ten).HasMaxLength(100);

                entity.Property(e => e.TenDangNhap)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<NhapHang>(entity =>
            {
                entity.ToTable("NhapHang");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IdnhanVien).HasColumnName("IDNhanVien");

                entity.Property(e => e.Ngay).HasColumnType("datetime");

                entity.Property(e => e.TongTien).HasColumnType("money");

                entity.HasOne(d => d.IdnhanVienNavigation)
                    .WithMany(p => p.NhapHangs)
                    .HasForeignKey(d => d.IdnhanVien)
                    .HasConstraintName("FK__NhapHang__IDNhan__7C4F7684");
            });

            modelBuilder.Entity<Nuoc>(entity =>
            {
                entity.ToTable("Nuoc");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Ten).HasMaxLength(100);
            });

            modelBuilder.Entity<PhanLoai>(entity =>
            {
                entity.ToTable("PhanLoai");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IddanhMuc).HasColumnName("IDDanhMuc");

                entity.Property(e => e.LinkImage)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Ten).HasMaxLength(100);

                entity.HasOne(d => d.IddanhMucNavigation)
                    .WithMany(p => p.PhanLoais)
                    .HasForeignKey(d => d.IddanhMuc)
                    .HasConstraintName("FK__PhanLoai__IDDanh__4D94879B");
            });

            modelBuilder.Entity<QuanLyChiDinh>(entity =>
            {
                entity.ToTable("QuanLyChiDinh");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IdchiDinh).HasColumnName("IDChiDinh");

                entity.Property(e => e.IdsanPham).HasColumnName("IDSanPham");

                entity.HasOne(d => d.IdchiDinhNavigation)
                    .WithMany(p => p.QuanLyChiDinhs)
                    .HasForeignKey(d => d.IdchiDinh)
                    .HasConstraintName("FK__QuanLyChi__IDChi__6A30C649");

                entity.HasOne(d => d.IdsanPhamNavigation)
                    .WithMany(p => p.QuanLyChiDinhs)
                    .HasForeignKey(d => d.IdsanPham)
                    .HasConstraintName("FK__QuanLyChi__IDSan__693CA210");
            });

            modelBuilder.Entity<QuanLyDoiTuong>(entity =>
            {
                entity.ToTable("QuanLyDoiTuong");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IddoiTuong).HasColumnName("IDDoiTuong");

                entity.Property(e => e.IdsanPham).HasColumnName("IDSanPham");

                entity.HasOne(d => d.IddoiTuongNavigation)
                    .WithMany(p => p.QuanLyDoiTuongs)
                    .HasForeignKey(d => d.IddoiTuong)
                    .HasConstraintName("FK__QuanLyDoi__IDDoi__6754599E");

                entity.HasOne(d => d.IdsanPhamNavigation)
                    .WithMany(p => p.QuanLyDoiTuongs)
                    .HasForeignKey(d => d.IdsanPham)
                    .HasConstraintName("FK__QuanLyDoi__IDSan__66603565");
            });

            modelBuilder.Entity<QuanLyHinhAnh>(entity =>
            {
                entity.ToTable("QuanLyHinhAnh");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.IdsanPham).HasColumnName("IDSanPham");

                entity.Property(e => e.Link)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.IdsanPhamNavigation)
                    .WithMany(p => p.QuanLyHinhAnhs)
                    .HasForeignKey(d => d.IdsanPham)
                    .HasConstraintName("FK__QuanLyHin__IDSan__6477ECF3");
            });

            modelBuilder.Entity<SanPham>(entity =>
            {
                entity.ToTable("SanPham");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.BaoQuan).HasMaxLength(500);

                entity.Property(e => e.CachDung).HasMaxLength(1000);

                entity.Property(e => e.CongDung).HasMaxLength(1000);

                entity.Property(e => e.HinhAnhChinh)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.IddangBaoChe).HasColumnName("IDDangBaoChe");

                entity.Property(e => e.IddonViTinh).HasColumnName("IDDonViTinh");

                entity.Property(e => e.IdloaiDa).HasColumnName("IDLoaiDa");

                entity.Property(e => e.IdmuiVi).HasColumnName("IDMuiVi");

                entity.Property(e => e.IdphanLoai).HasColumnName("IDPhanLoai");

                entity.Property(e => e.IdthuongHieu).HasColumnName("IDThuongHieu");

                entity.Property(e => e.LuuY).HasMaxLength(500);

                entity.Property(e => e.MoTaCuThe).HasMaxLength(4000);

                entity.Property(e => e.MoTaNgan).HasMaxLength(500);

                entity.Property(e => e.QuyCach).HasMaxLength(100);

                entity.Property(e => e.SoDangKy).HasMaxLength(100);

                entity.Property(e => e.TacDungPhu).HasMaxLength(500);

                entity.Property(e => e.Ten).HasMaxLength(200);

                entity.Property(e => e.ThanhPhan).HasMaxLength(500);

                entity.HasOne(d => d.IddangBaoCheNavigation)
                    .WithMany(p => p.SanPhams)
                    .HasForeignKey(d => d.IddangBaoChe)
                    .HasConstraintName("FK__SanPham__IDDangB__60A75C0F");

                entity.HasOne(d => d.IddonViTinhNavigation)
                    .WithMany(p => p.SanPhams)
                    .HasForeignKey(d => d.IddonViTinh)
                    .HasConstraintName("FK__SanPham__IDDonVi__5EBF139D");

                entity.HasOne(d => d.IdloaiDaNavigation)
                    .WithMany(p => p.SanPhams)
                    .HasForeignKey(d => d.IdloaiDa)
                    .HasConstraintName("FK__SanPham__IDLoaiD__160F4887");

                entity.HasOne(d => d.IdmuiViNavigation)
                    .WithMany(p => p.SanPhams)
                    .HasForeignKey(d => d.IdmuiVi)
                    .HasConstraintName("FK__SanPham__IDMuiVi__619B8048");

                entity.HasOne(d => d.IdphanLoaiNavigation)
                    .WithMany(p => p.SanPhams)
                    .HasForeignKey(d => d.IdphanLoai)
                    .HasConstraintName("FK__SanPham__IDPhanL__5FB337D6");

                entity.HasOne(d => d.IdthuongHieuNavigation)
                    .WithMany(p => p.SanPhams)
                    .HasForeignKey(d => d.IdthuongHieu)
                    .HasConstraintName("FK__SanPham__IDThuon__628FA481");
            });

            modelBuilder.Entity<ThuongHieu>(entity =>
            {
                entity.ToTable("ThuongHieu");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.AnhNhanHieu)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.DiaChi).HasMaxLength(500);

                entity.Property(e => e.IdxuatXu).HasColumnName("IDXuatXu");

                entity.Property(e => e.LinkImage).HasMaxLength(200);

                entity.Property(e => e.Ten).HasMaxLength(200);

                entity.HasOne(d => d.IdxuatXuNavigation)
                    .WithMany(p => p.ThuongHieus)
                    .HasForeignKey(d => d.IdxuatXu)
                    .HasConstraintName("FK__ThuongHie__IDXua__5629CD9C");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
