﻿using System;
using System.Collections.Generic;

namespace Doppl.Models
{
    public partial class ChiTietHoaDon
    {
        public int? IdhoaDon { get; set; }
        public int? IdsanPham { get; set; }
        public int? Soluong { get; set; }
        public int Id { get; set; }

        public virtual HoaDon? IdhoaDonNavigation { get; set; }
        public virtual SanPham? IdsanPhamNavigation { get; set; }
    }
}
