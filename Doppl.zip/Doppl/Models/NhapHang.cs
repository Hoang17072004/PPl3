﻿using System;
using System.Collections.Generic;

namespace Doppl.Models
{
    public partial class NhapHang
    {
        public NhapHang()
        {
            ChiTietNhapHangs = new HashSet<ChiTietNhapHang>();
        }

        public int Id { get; set; }
        public decimal? TongTien { get; set; }
        public int? IdnhanVien { get; set; }
        public DateTime? Ngay { get; set; }

        public virtual NhanVien? IdnhanVienNavigation { get; set; }
        public virtual ICollection<ChiTietNhapHang> ChiTietNhapHangs { get; set; }
    }
}
