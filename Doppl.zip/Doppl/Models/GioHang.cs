﻿using System;
using System.Collections.Generic;

namespace Doppl.Models
{
    public partial class GioHang
    {
        public GioHang()
        {
            ChiTietGioHangs = new HashSet<ChiTietGioHang>();
            HoaDons = new HashSet<HoaDon>();
        }

        public int Id { get; set; }
        public int? IdkhachHang { get; set; }

        public virtual KhachHang? IdkhachHangNavigation { get; set; }
        public virtual ICollection<ChiTietGioHang> ChiTietGioHangs { get; set; }
        public virtual ICollection<HoaDon> HoaDons { get; set; }
    }
}
