﻿using System;
using System.Collections.Generic;

namespace Doppl.Models
{
    public partial class DanhMuc
    {
        public DanhMuc()
        {
            PhanLoais = new HashSet<PhanLoai>();
        }

        public int Id { get; set; }
        public string? Ten { get; set; }
        public string? LinkImage { get; set; }

        public virtual ICollection<PhanLoai> PhanLoais { get; set; }
    }
}
