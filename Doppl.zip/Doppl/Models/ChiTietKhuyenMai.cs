﻿using System;
using System.Collections.Generic;

namespace Doppl.Models
{
    public partial class ChiTietKhuyenMai
    {
        public int? IdkhuyenMai { get; set; }
        public int? IdsanPham { get; set; }
        public int Id { get; set; }

        public virtual KhuyenMai? IdkhuyenMaiNavigation { get; set; }
        public virtual SanPham? IdsanPhamNavigation { get; set; }
    }
}
