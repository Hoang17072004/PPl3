﻿using System;
using System.Collections.Generic;

namespace Doppl.Models
{
    public partial class ChiTietGioHang
    {
        public int? IdgioHang { get; set; }
        public int? IdsanPham { get; set; }
        public int? Soluong { get; set; }
        public int Id { get; set; }

        public virtual GioHang? IdgioHangNavigation { get; set; }
        public virtual SanPham? IdsanPhamNavigation { get; set; }
    }
}
