﻿using System;
using System.Collections.Generic;

namespace Doppl.Models
{
    public partial class HoaDon
    {
        public HoaDon()
        {
            ChiTietHoaDons = new HashSet<ChiTietHoaDon>();
        }

        public int Id { get; set; }
        public decimal? TongTien { get; set; }
        public decimal? GiamGiaTrucTiep { get; set; }
        public int? GiamGiaVoucher { get; set; }
        public decimal? TietKiem { get; set; }
        public decimal? TamTinh { get; set; }
        public DateTime? Ngay { get; set; }
        public string? TrangThai { get; set; }
        public int? IdgioHang { get; set; }

        public virtual GioHang? IdgioHangNavigation { get; set; }
        public virtual ICollection<ChiTietHoaDon> ChiTietHoaDons { get; set; }
    }
}
