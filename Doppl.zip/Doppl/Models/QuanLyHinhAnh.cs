﻿using System;
using System.Collections.Generic;

namespace Doppl.Models
{
    public partial class QuanLyHinhAnh
    {
        public int? IdsanPham { get; set; }
        public string? Link { get; set; }
        public int Id { get; set; }

        public virtual SanPham? IdsanPhamNavigation { get; set; }
    }
}
