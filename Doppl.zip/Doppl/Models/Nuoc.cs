﻿using System;
using System.Collections.Generic;

namespace Doppl.Models
{
    public partial class Nuoc
    {
        public Nuoc()
        {
            ThuongHieus = new HashSet<ThuongHieu>();
        }

        public int Id { get; set; }
        public string? Ten { get; set; }

        public virtual ICollection<ThuongHieu> ThuongHieus { get; set; }
    }
}
