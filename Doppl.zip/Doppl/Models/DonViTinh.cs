﻿using System;
using System.Collections.Generic;

namespace Doppl.Models
{
    public partial class DonViTinh
    {
        public DonViTinh()
        {
            SanPhams = new HashSet<SanPham>();
        }

        public int Id { get; set; }
        public string? Ten { get; set; }

        public virtual ICollection<SanPham> SanPhams { get; set; }
    }
}
