﻿using System;
using System.Collections.Generic;

namespace Doppl.Models
{
    public partial class NhanVien
    {
        public NhanVien()
        {
            NhapHangs = new HashSet<NhapHang>();
        }

        public int Id { get; set; }
        public string? Ten { get; set; }
        public string? DiaChi { get; set; }
        public DateTime? NgaySinh { get; set; }
        public string? SoDienThoai { get; set; }
        public string? TenDangNhap { get; set; }
        public string? MatKhau { get; set; }

        public virtual ICollection<NhapHang> NhapHangs { get; set; }
    }
}
