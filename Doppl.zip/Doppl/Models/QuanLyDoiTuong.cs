﻿using System;
using System.Collections.Generic;

namespace Doppl.Models
{
    public partial class QuanLyDoiTuong
    {
        public int? IdsanPham { get; set; }
        public int? IddoiTuong { get; set; }
        public int Id { get; set; }

        public virtual DoiTuong? IddoiTuongNavigation { get; set; }
        public virtual SanPham? IdsanPhamNavigation { get; set; }
    }
}
