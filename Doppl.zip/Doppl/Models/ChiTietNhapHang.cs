﻿using System;
using System.Collections.Generic;

namespace Doppl.Models
{
    public partial class ChiTietNhapHang
    {
        public int? IdnhapHang { get; set; }
        public int? IdloHang { get; set; }
        public int Id { get; set; }

        public virtual LoHang? IdloHangNavigation { get; set; }
        public virtual NhapHang? IdnhapHangNavigation { get; set; }
    }
}
