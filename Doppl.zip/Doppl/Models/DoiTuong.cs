﻿using System;
using System.Collections.Generic;

namespace Doppl.Models
{
    public partial class DoiTuong
    {
        public DoiTuong()
        {
            QuanLyDoiTuongs = new HashSet<QuanLyDoiTuong>();
        }

        public int Id { get; set; }
        public string? Ten { get; set; }

        public virtual ICollection<QuanLyDoiTuong> QuanLyDoiTuongs { get; set; }
    }
}
