﻿using System;
using System.Collections.Generic;

namespace Doppl.Models
{
    public partial class LoHang
    {
        public LoHang()
        {
            ChiTietNhapHangs = new HashSet<ChiTietNhapHang>();
        }

        public int Id { get; set; }
        public int? IdsanPham { get; set; }
        public int? Soluong { get; set; }
        public DateTime? NgaySanXuat { get; set; }
        public DateTime? NgayHetHan { get; set; }
        public decimal? GiaVon { get; set; }
        public decimal? GiaBan { get; set; }
        public int? SoluongCon { get; set; }

        public virtual SanPham? IdsanPhamNavigation { get; set; }
        public virtual ICollection<ChiTietNhapHang> ChiTietNhapHangs { get; set; }
    }
}
