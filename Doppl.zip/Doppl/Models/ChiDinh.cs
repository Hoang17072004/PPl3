﻿using System;
using System.Collections.Generic;

namespace Doppl.Models
{
    public partial class ChiDinh
    {
        public ChiDinh()
        {
            QuanLyChiDinhs = new HashSet<QuanLyChiDinh>();
        }

        public int Id { get; set; }
        public string? Ten { get; set; }

        public virtual ICollection<QuanLyChiDinh> QuanLyChiDinhs { get; set; }
    }
}
