﻿using System;
using System.Collections.Generic;

namespace Doppl.Models
{
    public partial class ThuongHieu
    {
        public ThuongHieu()
        {
            SanPhams = new HashSet<SanPham>();
        }

        public int Id { get; set; }
        public string? Ten { get; set; }
        public string? LinkImage { get; set; }
        public string? MoTa { get; set; }
        public string? DiaChi { get; set; }
        public int? IdxuatXu { get; set; }
        public string? AnhNhanHieu { get; set; }

        public virtual Nuoc? IdxuatXuNavigation { get; set; }
        public virtual ICollection<SanPham> SanPhams { get; set; }
    }
}
