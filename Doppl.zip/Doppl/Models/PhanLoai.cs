﻿using System;
using System.Collections.Generic;

namespace Doppl.Models
{
    public partial class PhanLoai
    {
        public PhanLoai()
        {
            SanPhams = new HashSet<SanPham>();
        }

        public int Id { get; set; }
        public int? IddanhMuc { get; set; }
        public string? Ten { get; set; }
        public string? LinkImage { get; set; }

        public virtual DanhMuc? IddanhMucNavigation { get; set; }
        public virtual ICollection<SanPham> SanPhams { get; set; }
    }
}
