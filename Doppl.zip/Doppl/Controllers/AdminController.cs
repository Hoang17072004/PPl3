﻿using Doppl.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing.Printing;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Intrinsics.Arm;
using System.Web;
using System.Xml.Linq;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;


namespace Doppl.Controllers
{
     
    public class AdminController :Controller
    {
        public  QuanLyThuocContext db = new QuanLyThuocContext();
        
        private readonly IWebHostEnvironment _webHost;
        public static bool isadmin =false;

        public static  int idemployee = 2;
        public static int idadmin = 1;
        
        public AdminController(IWebHostEnvironment webHost)
        {
            _webHost = webHost;
            
        }

        public IActionResult ProductDetail()
        {
            ViewBag.isadmin = isadmin;
            ViewBag.idemployee = idemployee;
            ViewBag.idadmin = idadmin;
            return View();
        }
        [HttpGet]
        public IActionResult AddProduct()
        {
            
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> AddProduct(SanPham product,List<IFormFile> files,List<int> checkboxes,List<int> persons)
        {
           
            if (product.IdmuiVi == 0) product.IdmuiVi = null;
            if (product.IdloaiDa == 0) product.IdloaiDa = null;
            string uploadsFolder = Path.Combine(_webHost.WebRootPath,"uploads");
            if (!Directory.Exists(uploadsFolder))
            {
                Directory.CreateDirectory(uploadsFolder);
            }
            int IDProduct = -1;
            for (int i=0;i<files.Count; i++)
            {
                string fileName = Path.GetFileName(files[i].FileName);
                string fileSavePath=Path.Combine(uploadsFolder,fileName);
                if (i==0)
                {
                    product.HinhAnhChinh = fileSavePath.Substring(fileSavePath.IndexOf("uploads"));
                    db.SanPhams.Add(product);
                    db.SaveChanges();
                    IDProduct = db.SanPhams.Max(p => p.Id);
                }
                using(FileStream stream=new FileStream(fileSavePath,FileMode.Create))
                {
                    await files[i].CopyToAsync(stream);
                }
                
                
                db.QuanLyHinhAnhs.Add(new QuanLyHinhAnh { IdsanPham=IDProduct,Link= fileSavePath.Substring(fileSavePath.IndexOf("uploads")) });
                

            }
            foreach(int x in checkboxes)
            {
                db.QuanLyChiDinhs.Add(new QuanLyChiDinh { IdsanPham = IDProduct, IdchiDinh = x });
            }
            foreach(int x in persons)
            {
                db.QuanLyDoiTuongs.Add(new QuanLyDoiTuong { IddoiTuong = x, IdsanPham = IDProduct });
            }
            db.SaveChanges();
            return RedirectToAction("ProductDetail");
        }
        [HttpGet]
        public IActionResult EditProduct(int id=24)
        {
            

            return View(db.SanPhams.FirstOrDefault(p=>p.Id==id));
        }
        [HttpPost]
        public async Task<IActionResult> EditProduct(SanPham product, List<IFormFile> files, List<int> checkboxes, List<int> persons,List<int> remainfiles) 
        {
            

            if (product.IdmuiVi == 0) product.IdmuiVi = null;
            if (product.IdloaiDa == 0) product.IdloaiDa = null;
            #region EditProduct
            var tempproduct = db.SanPhams.FirstOrDefault(p => p.Id == product.Id);
            tempproduct!.IddonViTinh = product.IddonViTinh;
            tempproduct.IdphanLoai = product.IdphanLoai;
            tempproduct.IddangBaoChe = product.IddangBaoChe;
            tempproduct.QuyCach = product.QuyCach;
            tempproduct.IdmuiVi = product.IdmuiVi;
            tempproduct.IdthuongHieu = product.IdthuongHieu;
            tempproduct.ThanhPhan = product.ThanhPhan;
            tempproduct.MoTaNgan = product.MoTaNgan;
            tempproduct.SoDangKy = product.SoDangKy;
            tempproduct.MoTaCuThe = product.MoTaCuThe;
            tempproduct.CongDung = product.CongDung;
            tempproduct.CachDung = product.CachDung;
            tempproduct.TacDungPhu = product.TacDungPhu;
            tempproduct.LuuY = product.LuuY;
            tempproduct.BaoQuan = product.BaoQuan;
            tempproduct.IdloaiDa = product.IdloaiDa;
            tempproduct.Ten = product.Ten;
            #endregion
            db.SaveChanges();
            var listImageDelete =db.QuanLyHinhAnhs.Where(p=>p.IdsanPham==product.Id&& remainfiles.Contains(p.Id)==false);
            foreach(var item in listImageDelete)
            {
                db.QuanLyHinhAnhs.Remove(item);
            }
            int IDProduct = product.Id;
            string uploadsFolder = Path.Combine(_webHost.WebRootPath, "uploads");
            for (int i = 0; i < files.Count; i++)
            {
                string fileName = Path.GetFileName(files[i].FileName);
                string fileSavePath = Path.Combine(uploadsFolder, fileName);
               
                using (FileStream stream = new FileStream(fileSavePath, FileMode.Create))
                {
                    await files[i].CopyToAsync(stream);
                }


                db.QuanLyHinhAnhs.Add(new QuanLyHinhAnh { IdsanPham = IDProduct, Link = fileSavePath.Substring(fileSavePath.IndexOf("uploads")) });


            }
            var listFunctionDelete = db.QuanLyChiDinhs.Where(p => p.IdsanPham == IDProduct);
            foreach (var item in listFunctionDelete)
            {
                db.QuanLyChiDinhs.Remove(item);
            }
            var listPersonDelete = db.QuanLyDoiTuongs.Where(p => p.IdsanPham == IDProduct);
            foreach(var item in listPersonDelete)
            {
                db.QuanLyDoiTuongs.Remove(item);
            }
            foreach (int x in checkboxes)
            {
                db.QuanLyChiDinhs.Add(new QuanLyChiDinh { IdsanPham = IDProduct, IdchiDinh = x });
            }
            foreach (int x in persons)
            {
                db.QuanLyDoiTuongs.Add(new QuanLyDoiTuong { IddoiTuong = x, IdsanPham = IDProduct });
            }
            var linkmainimage = db.QuanLyHinhAnhs.FirstOrDefault(q => q.IdsanPham == IDProduct);
            var tempImageAfterChange = db.SanPhams.FirstOrDefault(p => p.Id == IDProduct);
            if (linkmainimage != null)
            {
                tempImageAfterChange!.HinhAnhChinh = linkmainimage.Link;
            }
            else tempImageAfterChange!.HinhAnhChinh = "upload\\noimage.png";
            db.SaveChanges();
            return RedirectToAction("ProductDetail");
        }
        public IActionResult ShowDetailProduct(int id=24)
        {
            ViewBag.isadmin = isadmin;
            ViewBag.idemployee = idemployee;
            ViewBag.idadmin = idadmin;
            return View(db.SanPhams.FirstOrDefault(p=>p.Id==id));
        }
        public IActionResult ImportDetail()
        {
            ViewBag.isadmin = isadmin;
            ViewBag.idemployee = idemployee;
            ViewBag.idadmin = idadmin;
            return View();
        }
        public IActionResult AddImport(int idemployee=1)
        {
            
            return View(db.NhanViens.FirstOrDefault(p=>p.Id==AdminController.idemployee));
        }
        [HttpPost]
        public IActionResult ReceiveAddImport(int IDNhanVien, List<LoHang> listLoHangs)
        {
            if (listLoHangs.Count>0)
            {
                listLoHangs[0].SoluongCon = listLoHangs[0].Soluong;
                db.LoHangs.Add(listLoHangs[0]);
                db.SaveChanges();
                int idstart = db.LoHangs.Max(p => p.Id);
                List<int> ids = new List<int> { idstart };
                decimal? totalmoney = listLoHangs[0].Soluong * listLoHangs[0].GiaVon;
                for (int i=1;i<listLoHangs.Count;i++)
                {
                    ids.Add(ids[i - 1] + 1);
                    listLoHangs[i].SoluongCon = listLoHangs[i].Soluong;
                    totalmoney += listLoHangs[i].Soluong * listLoHangs[i].GiaVon;
                    db.LoHangs.Add(listLoHangs[i]);
                }
                db.NhapHangs.Add(new NhapHang { IdnhanVien = IDNhanVien, TongTien = totalmoney, Ngay = DateTime.Now });
                db.SaveChanges();
                int idimport = db.NhapHangs.Max(p => p.Id);
                foreach (var item in ids)
                {
                    db.ChiTietNhapHangs.Add(new ChiTietNhapHang { IdnhapHang = idimport, IdloHang = item });
                }
                db.SaveChanges();
            }
            return RedirectToAction("ImportDetail");
        }
        public IActionResult EmployeeDetail()
        {
            ViewBag.isadmin = isadmin;
            ViewBag.idemployee = idemployee;
            ViewBag.idadmin = idadmin;
            return View();
        }
        [HttpGet]
        public IActionResult AddEmployee()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AddEmployee(NhanVien employee)
        {
            db.NhanViens.Add(employee);
            db.SaveChanges();
            return RedirectToAction("EmployeeDetail");
        }
        [HttpGet]
        public IActionResult UpdateEmployee(int id=2)
        {
            var employee = db.NhanViens.FirstOrDefault(p => p.Id == id);
            return View(employee);
        }
        [HttpPost]
        public IActionResult UpdateEmployee(NhanVien employee)
        {
            var original = db.NhanViens.FirstOrDefault(p => p.Id == employee.Id);
            original!.Ten = employee.Ten;
            original!.DiaChi = employee.DiaChi;
            original!.NgaySinh = employee.NgaySinh;
            original!.SoDienThoai = employee.SoDienThoai;
            original!.TenDangNhap = employee.TenDangNhap;
            original!.MatKhau = employee.MatKhau;
            db.SaveChanges();
            return RedirectToAction("EmployeeDetail");
        }
        public IActionResult BrandDetail()
        {
            ViewBag.isadmin = isadmin;
            ViewBag.idemployee = idemployee;
            ViewBag.idadmin = idadmin;
            return View();
        }
        [HttpGet]
        public IActionResult AddBrand()
        {

            return View(db.Nuocs);
        }
        [HttpPost]
        public async Task<IActionResult>  AddBrand(ThuongHieu brand,IFormFile MainImage,IFormFile BrandImage)
        {
            string uploadsFolder = Path.Combine(_webHost.WebRootPath, "uploads");
            if (!Directory.Exists(uploadsFolder))
            {
                Directory.CreateDirectory(uploadsFolder);
            }
            string fileName = Path.GetFileName(MainImage.FileName);
            string fileSavePath = Path.Combine(uploadsFolder, fileName);
            brand.LinkImage= fileSavePath.Substring(fileSavePath.IndexOf("uploads"));
            using (FileStream stream = new FileStream(fileSavePath, FileMode.Create))
            {
                await MainImage.CopyToAsync(stream);
            }
            fileName = Path.GetFileName(BrandImage.FileName);
            fileSavePath = Path.Combine(uploadsFolder, fileName);
            brand.AnhNhanHieu= fileSavePath.Substring(fileSavePath.IndexOf("uploads"));
            using (FileStream stream = new FileStream(fileSavePath, FileMode.Create))
            {
                await BrandImage.CopyToAsync(stream);
            }
            db.ThuongHieus.Add(brand);
            db.SaveChanges();
            return RedirectToAction("BrandDetail");
        }
        [HttpGet]
        public IActionResult EditBrand(int id=1)
        {
            var brand = db.ThuongHieus.FirstOrDefault(p => p.Id == id);
            return View(brand);
        }
        [HttpPost]
        public async Task<IActionResult> EditBrand(ThuongHieu brand,IFormFile newMainImage,IFormFile newBrandImage)
        {
            if (newMainImage!=null)
            {
                string uploadsFolder = Path.Combine(_webHost.WebRootPath, "uploads");
                if (!Directory.Exists(uploadsFolder))
                {
                    Directory.CreateDirectory(uploadsFolder);
                }
                string fileName = Path.GetFileName(newMainImage.FileName);
                string fileSavePath = Path.Combine(uploadsFolder, fileName);
                brand.LinkImage = fileSavePath.Substring(fileSavePath.IndexOf("uploads"));
                using (FileStream stream = new FileStream(fileSavePath, FileMode.Create))
                {
                    await newMainImage.CopyToAsync(stream);
                }
                
            }
            if (newBrandImage!=null)
            {
                string uploadsFolder = Path.Combine(_webHost.WebRootPath, "uploads");
                if (!Directory.Exists(uploadsFolder))
                {
                    Directory.CreateDirectory(uploadsFolder);
                }
                string fileName = Path.GetFileName(newBrandImage.FileName);
                string fileSavePath = Path.Combine(uploadsFolder, fileName);
                brand.AnhNhanHieu = fileSavePath.Substring(fileSavePath.IndexOf("uploads"));
                using (FileStream stream = new FileStream(fileSavePath, FileMode.Create))
                {
                    await newBrandImage.CopyToAsync(stream);
                }
            }
            var original = db.ThuongHieus.FirstOrDefault(p => p.Id == brand.Id);
            original!.Ten = brand.Ten;
            if (brand.LinkImage != null) original!.LinkImage = brand.LinkImage;
            original!.MoTa = brand.MoTa;
            original!.DiaChi = brand.DiaChi;
            original!.IdxuatXu = brand.IdxuatXu;
            if (brand.AnhNhanHieu != null) original!.AnhNhanHieu = brand.AnhNhanHieu;
            db.SaveChanges();
            return RedirectToAction("BrandDetail");
        }
        public IActionResult PromotionDetail()
        {
            ViewBag.isadmin = isadmin;
            ViewBag.idemployee = idemployee;
            ViewBag.idadmin = idadmin;
            return View();
        }
        [HttpGet]
        public IActionResult AddPromotion()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AddPromotion(KhuyenMai promotion,List<int> products)
        {
            db.KhuyenMais.Add(promotion);
            db.SaveChanges();
            int idpromotion = db.KhuyenMais.Max(p => p.Id);
            foreach (int item in products)
            {
                db.ChiTietKhuyenMais.Add(new ChiTietKhuyenMai { IdkhuyenMai = idpromotion, IdsanPham = item });   
            }
            db.SaveChanges();
            return RedirectToAction("PromotionDetail");
        }
        public IActionResult BillDetail()
        {
            ViewBag.isadmin = isadmin;
            ViewBag.idemployee = idemployee;
            ViewBag.idadmin = idadmin;

            return View();
        }
        public IActionResult UserDetail()
        {
            ViewBag.isadmin = isadmin;
            ViewBag.idemployee = idemployee;
            ViewBag.idadmin = idadmin;
            return View();
        }
        public IActionResult Overview()
        {
            ViewBag.isadmin = isadmin;
            ViewBag.idemployee = idemployee;
            ViewBag.idadmin = idadmin;
            return View();
        }
        [HttpGet]
        public IActionResult EditImport(int idimport=2,int idemployee=2)
        {
            NhanVien employee = db.NhanViens.FirstOrDefault(p => p.Id == AdminController.idemployee);
            NhapHang import = db.NhapHangs.FirstOrDefault(p => p.Id == idimport);
           
            Tuple<NhanVien, NhapHang> tuple = new Tuple<NhanVien, NhapHang>(employee,import);
           
            return View(tuple);
        }
        [HttpPost]
        public IActionResult EditImport(NhapHang import, List<LoHang> listLoHangs)
        {
            var needdelete = from d in db.ChiTietNhapHangs.Where(p => p.IdnhapHang == import.Id)
                             join s in db.LoHangs on d.IdloHang equals s.Id
                             select s;
            var detailwilldelete = db.ChiTietNhapHangs.Where(p => p.IdnhapHang == import.Id);
            foreach (var item in detailwilldelete) db.ChiTietNhapHangs.Remove(item);
            foreach (var item in needdelete) db.LoHangs.Remove(item);

            db.SaveChanges();
            
            if (listLoHangs.Count > 0)
            {
                listLoHangs[0].SoluongCon = listLoHangs[0].Soluong;
                db.LoHangs.Add(listLoHangs[0]);
                db.SaveChanges();
                int idstart = db.LoHangs.Max(p => p.Id);
                List<int> ids = new List<int> { idstart };
                decimal? totalmoney = listLoHangs[0].Soluong * listLoHangs[0].GiaVon;
                for (int i = 1; i < listLoHangs.Count; i++)
                {
                    ids.Add(ids[i - 1] + 1);
                    listLoHangs[i].SoluongCon = listLoHangs[i].Soluong;
                    totalmoney += listLoHangs[i].Soluong * listLoHangs[i].GiaVon;
                    db.LoHangs.Add(listLoHangs[i]);
                }
                var original = db.NhapHangs.FirstOrDefault(p => p.Id == import.Id);
                original.IdnhanVien = import.IdnhanVien;
                original.Ngay = import.Ngay;
                original.TongTien = totalmoney;
                
                
                int idimport = original.Id;
                foreach (var item in ids)
                {
                    db.ChiTietNhapHangs.Add(new ChiTietNhapHang { IdnhapHang = idimport, IdloHang = item });
                }
                db.SaveChanges();
            }

            return RedirectToAction("ImportDetail");
        }
        [HttpGet]
        public IActionResult EditPromotion(int idpromotion = 1)
        {
            return View(db.KhuyenMais.FirstOrDefault(p => p.Id == idpromotion));
        }
        [HttpPost]
        public IActionResult EditPromotion(KhuyenMai promotion, List<int> products)
        {
            var original = db.KhuyenMais.FirstOrDefault(p => p.Id == promotion.Id);
            var needdelete = db.ChiTietKhuyenMais.Where(p => p.IdkhuyenMai == promotion.Id);
            foreach (var item in needdelete) db.ChiTietKhuyenMais.Remove(item);
            original.Ten = promotion.Ten;
            original.Mota = promotion.Mota;
            original.NgayBatDau = promotion.NgayBatDau;
            original.NgayKetThuc = promotion.NgayKetThuc;
            original.TiLeGiamGia = promotion.TiLeGiamGia;
            db.SaveChanges();
            foreach (var item in products)
            {
                db.ChiTietKhuyenMais.Add(new ChiTietKhuyenMai { IdkhuyenMai = promotion.Id, IdsanPham = item });
            }
            db.SaveChanges();
            return RedirectToAction("PromotionDetail");
        }
        [HttpGet]
        public IActionResult EditEmployee(int idemployee=2)
        {
            return View(db.NhanViens.FirstOrDefault(p => p.Id == idemployee));
        }
        [HttpPost]
        public IActionResult EditEmployee(NhanVien employee)
        {
            var original = db.NhanViens.FirstOrDefault(p => p.Id == employee.Id);
            original.Ten = employee.Ten;
            original.DiaChi = employee.DiaChi;
            original.NgaySinh = employee.NgaySinh;
            original.SoDienThoai = employee.SoDienThoai;
            original.TenDangNhap = employee.TenDangNhap;
            original.MatKhau = employee.MatKhau;
            db.SaveChanges();
            return RedirectToAction("EmployeeDetail");
        }
        [HttpGet]
        public IActionResult EditAdmin(int idamin=1)
        {
            return View(db.Admins.FirstOrDefault(p => p.Id ==idadmin));
        }
        [HttpPost]
        public IActionResult EditAdmin(Admin admin)
        {
            var original = db.Admins.FirstOrDefault(p => p.Id == admin.Id);
            original.Ten = admin.Ten;
            original.DiaChi = admin.DiaChi;
            original.NgaySinh = admin.NgaySinh;
            original.Email = admin.Email;
            original.SoDienThoai = admin.SoDienThoai;
            original.TenDangNhap = admin.TenDangNhap;
            original.MatKhau = admin.MatKhau;
            db.SaveChanges();
            return View(admin);
        }
        [HttpGet]
        public IActionResult LoginAdmin()
        {
            return View(true);
        }
        [HttpPost]
        public IActionResult LoginAdmin(string username,string password) 
        {
            var find = db.Admins.FirstOrDefault(p => p.TenDangNhap == username && p.MatKhau == password);
            if (find == null) return View(false);
            isadmin = true;
            idadmin = find.Id;
            return RedirectToAction("BillDetail");
        }
        [HttpGet]
        public IActionResult LoginEmployee()
        {
            return View(true);
        }
        [HttpPost]
        public IActionResult LoginEmployee(string username, string password)
        {
            var find = db.NhanViens.FirstOrDefault(p => p.TenDangNhap == username && p.MatKhau == password);
            if (find == null) return View(false);
            isadmin = false;
            idemployee = find.Id;
            return RedirectToAction("BillDetail");
        }
        #region resultJSon
        int numpage = 1;
        [HttpGet]
        public JsonResult GetAllProduct(int page=1)
        {
            
            var listoriginalProducts = from product in db.SanPhams
                                       join unit in db.DonViTinhs on product.IddonViTinh equals unit.Id
                                       join dosage in db.DangBaoChes on product.IddangBaoChe equals dosage.Id
                                       join brand in db.ThuongHieus on product.IdthuongHieu equals brand.Id
                                       select new
                                       {
                                           name = product.Ten,
                                           image = product.HinhAnhChinh,
                                           unitname = unit.Ten,
                                           dosagename = dosage.Ten,
                                           specipications = product.QuyCach,
                                           branname = brand.Ten,
                                           id=product.Id,
                                           idbrand=product.IdthuongHieu,
                                           idskin=product.IdloaiDa,
                                           idtaste=product.IdmuiVi
                                       };
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var temp = new
            {
                product=listoriginalProducts.Take(take).Skip(skip),
                count=listoriginalProducts.Count()-take
            };
            return new JsonResult(Ok(temp));
        }
        [HttpGet]
        public JsonResult GetProductByName(string name,int page=1)
        {
            
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var listoriginalProducts = from product in db.SanPhams
                                       join unit in db.DonViTinhs on product.IddonViTinh equals unit.Id
                                       join dosage in db.DangBaoChes on product.IddangBaoChe equals dosage.Id
                                       join brand in db.ThuongHieus on product.IdthuongHieu equals brand.Id
                                       select new
                                       {
                                           name = product.Ten,
                                           image = product.HinhAnhChinh,
                                           unitname = unit.Ten,
                                           dosagename = dosage.Ten,
                                           specipications = product.QuyCach,
                                           branname = brand.Ten,
                                           id = product.Id,
                                           idbrand = product.IdthuongHieu,
                                           idskin = product.IdloaiDa,
                                           idtaste = product.IdmuiVi
                                       };
            var query = listoriginalProducts.Where(p => p.name!.ToLower().Contains(name.ToLower()));
            var temp = new
            {
                product=query.Take(take).Skip(skip),
                count=query.Count()-take,
                search=name
            };
            return new JsonResult(Ok(temp));
        }
        [HttpGet]
        public JsonResult GetProductByIDBrand(int idbrand,int page=1)
        {
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var listoriginalProducts = from product in db.SanPhams
                                       join unit in db.DonViTinhs on product.IddonViTinh equals unit.Id
                                       join dosage in db.DangBaoChes on product.IddangBaoChe equals dosage.Id
                                       join brand in db.ThuongHieus on product.IdthuongHieu equals brand.Id
                                       select new
                                       {
                                           name = product.Ten,
                                           image = product.HinhAnhChinh,
                                           unitname = unit.Ten,
                                           dosagename = dosage.Ten,
                                           specipications = product.QuyCach,
                                           branname = brand.Ten,
                                           id = product.Id,
                                           idbrand = product.IdthuongHieu,
                                           idskin = product.IdloaiDa,
                                           idtaste = product.IdmuiVi
                                       };
            var query = listoriginalProducts.Where(p => p.idbrand == idbrand);
            var temp = new
            {
                product = query.Take(take).Skip(skip),
                count = query.Count() - take
            };
            return new JsonResult(Ok(temp));

        }
        [HttpGet]
        public JsonResult GetProductByIDSkin(int idskin,int page=1)
        {
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var listoriginalProducts = from product in db.SanPhams
                                       join unit in db.DonViTinhs on product.IddonViTinh equals unit.Id
                                       join dosage in db.DangBaoChes on product.IddangBaoChe equals dosage.Id
                                       join brand in db.ThuongHieus on product.IdthuongHieu equals brand.Id
                                       select new
                                       {
                                           name = product.Ten,
                                           image = product.HinhAnhChinh,
                                           unitname = unit.Ten,
                                           dosagename = dosage.Ten,
                                           specipications = product.QuyCach,
                                           branname = brand.Ten,
                                           id = product.Id,
                                           idbrand = product.IdthuongHieu,
                                           idskin = product.IdloaiDa,
                                           idtaste = product.IdmuiVi
                                       };
            var query = listoriginalProducts.Where(p => p.idskin == idskin);
            var temp = new
            {
                product = query.Take(take).Skip(skip),
                count = query.Count() - take
            };
            return new JsonResult(Ok(temp));

            
        }
        [HttpGet]
        public JsonResult GetProductByIDTaste(int idtaste,int page=1)
        {
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var listoriginalProducts = from product in db.SanPhams
                                       join unit in db.DonViTinhs on product.IddonViTinh equals unit.Id
                                       join dosage in db.DangBaoChes on product.IddangBaoChe equals dosage.Id
                                       join brand in db.ThuongHieus on product.IdthuongHieu equals brand.Id
                                       select new
                                       {
                                           name = product.Ten,
                                           image = product.HinhAnhChinh,
                                           unitname = unit.Ten,
                                           dosagename = dosage.Ten,
                                           specipications = product.QuyCach,
                                           branname = brand.Ten,
                                           id = product.Id,
                                           idbrand = product.IdthuongHieu,
                                           idskin = product.IdloaiDa,
                                           idtaste = product.IdmuiVi
                                       };
            var query = listoriginalProducts.Where(p => p.idtaste == idtaste);
            var temp = new
            {
                product = query.Take(take).Skip(skip),
                count = query.Count() - take
            };
            return new JsonResult(Ok(temp));

        }
        [HttpPost]
        public JsonResult GetProductByIDFunction(int[] ids,int page=1)
        {
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var uniqueID = db.QuanLyChiDinhs.Where(p => ids.Contains((int)p.IdchiDinh!)).Select(p => p.IdsanPham).Distinct();
            var listoriginalProducts = from product in db.SanPhams
                                       join unit in db.DonViTinhs on product.IddonViTinh equals unit.Id
                                       join dosage in db.DangBaoChes on product.IddangBaoChe equals dosage.Id
                                       join brand in db.ThuongHieus on product.IdthuongHieu equals brand.Id
                                       select new
                                       {
                                           name = product.Ten,
                                           image = product.HinhAnhChinh,
                                           unitname = unit.Ten,
                                           dosagename = dosage.Ten,
                                           specipications = product.QuyCach,
                                           branname = brand.Ten,
                                           id = product.Id,
                                           idbrand = product.IdthuongHieu,
                                           idskin = product.IdloaiDa,
                                           idtaste = product.IdmuiVi
                                       };
            var query =listoriginalProducts.Where(p => uniqueID.Contains(p.id));
            var temp = new
            {
                product = query.Take(take).Skip(skip),
                count = query.Count() - take
            };
            return new JsonResult(Ok(temp));
            
        }
        [HttpPost]
        public JsonResult GetProductByIDObject(int[] ids,int page=1)
        {
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var uniqueID = db.QuanLyDoiTuongs.Where(p => ids.Contains((int)p.IddoiTuong!)).Select(p => p.IdsanPham).Distinct();
            var listoriginalProducts = from product in db.SanPhams
                                       join unit in db.DonViTinhs on product.IddonViTinh equals unit.Id
                                       join dosage in db.DangBaoChes on product.IddangBaoChe equals dosage.Id
                                       join brand in db.ThuongHieus on product.IdthuongHieu equals brand.Id
                                       select new
                                       {
                                           name = product.Ten,
                                           image = product.HinhAnhChinh,
                                           unitname = unit.Ten,
                                           dosagename = dosage.Ten,
                                           specipications = product.QuyCach,
                                           branname = brand.Ten,
                                           id = product.Id,
                                           idbrand = product.IdthuongHieu,
                                           idskin = product.IdloaiDa,
                                           idtaste = product.IdmuiVi
                                       };
            var query = listoriginalProducts.Where(p => uniqueID.Contains(p.id ));
            var temp = new
            {
                product = query.Take(take).Skip(skip),
                count = query.Count() - take
            };
            return new JsonResult(Ok(temp));
            
        }
        [HttpGet]
        public JsonResult GetShipmentByIDImport(int idImport)
        {
            var listIDShipment = db.ChiTietNhapHangs.Where(p => p.IdnhapHang == idImport).Select(p => p.IdloHang);
            var temp = from i in listIDShipment
                       join s in db.LoHangs on i equals s.Id
                       join p in db.SanPhams on s.IdsanPham equals p.Id
                       select new
                       {
                           image = p.HinhAnhChinh,
                           name = p.Ten,
                           quantity = s.Soluong,
                           cost = s.GiaVon,
                           price = s.GiaBan,
                           datemanufaction = s.NgaySanXuat,
                           dateexpiration = s.NgayHetHan,
                           remainquantity=s.SoluongCon,
                           id=s.Id,
                           idproduct=s.IdsanPham
                       };
            return new JsonResult(Ok(temp));
        }
        
        [HttpGet]
        public JsonResult GetAllImport(int page=1)
        {
            var query = from i in db.NhapHangs
                       join e in db.NhanViens on i.IdnhanVien equals e.Id
                       select new
                       {
                           employeename = e.Ten,
                           id = i.Id,
                           date = i.Ngay,
                           money = i.TongTien
                       };
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var temp = new
            {
                shipment = query.Take(take).Skip(skip),
                count = query.Count() - take
            };
            return new JsonResult(Ok(temp));
        }
        [HttpGet]
        public JsonResult GetImportByEmployeeName(string employeename,int page=1)
        {
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var query = from i in db.NhapHangs
                        join e in db.NhanViens.Where(p=>p.Ten!.ToLower().Contains(employeename.ToLower())) on i.IdnhanVien equals e.Id
                        select new
                        {
                            employeename = e.Ten,
                            id = i.Id,
                            date = i.Ngay,
                            money = i.TongTien
                        };
            var temp = new
            {
                shipment = query.Take(take).Skip(skip),
                count = query.Count() - take
            };
            return new JsonResult(Ok(temp));
        }
        [HttpGet]
        public JsonResult GetImportFromDate(DateTime date,int page=1)
        {
            var query = from i in db.NhapHangs.Where(p=>p.Ngay>=date)
                        join e in db.NhanViens on i.IdnhanVien equals e.Id
                        select new
                        {
                            employeename = e.Ten,
                            id = i.Id,
                            date = i.Ngay,
                            money = i.TongTien
                        };
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var temp = new
            {
                shipment = query.Take(take).Skip(skip),
                count = query.Count() - take
            };
            return new JsonResult(Ok(temp));
        }
        [HttpGet]
        public JsonResult GetAllEmployee(int page=1)
        {
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var temp = new
            {
                employee = db.NhanViens.Take(take).Skip(skip),
                count = db.NhanViens.Count() - take
            };
            return new JsonResult(Ok(temp));
        }
        [HttpGet]
        public JsonResult GetEmployeeByName(string name,int page=1)
        {
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var query = db.NhanViens.Where(p => p.Ten.ToLower().Contains(name.ToLower()));
            var temp = new
            {
                employee = query.Take(take).Skip(skip),
                count = query.Count()-take
            };
            return new JsonResult(Ok(temp));
        }
        [HttpGet]
        public JsonResult GetAllBrand()
        {
            var temp = from b in db.ThuongHieus
                       join c in db.Nuocs on b.IdxuatXu equals c.Id
                       select new
                       {
                           name = b.Ten,
                           id = b.Id,
                           linkImage = b.LinkImage,
                           description = b.MoTa,
                           address = b.DiaChi,
                           countryname = c.Ten,
                           brandimage = b.AnhNhanHieu,
                           idcountry=b.IdxuatXu
                       };
            return new JsonResult(Ok(temp));
        }
        [HttpGet]
        public JsonResult GetAllCountry()
        {
            return new JsonResult(Ok(db.Nuocs));
        
        }
        [HttpGet]
        public JsonResult GetAllFunction()
        {
            return new JsonResult(Ok(db.ChiDinhs));
        }
        [HttpGet]
        public JsonResult GetAllSkin()
        {
            return new JsonResult(Ok(db.LoaiDa));
        }
        [HttpGet]
        public JsonResult GetAllTaste()
        {
            return new JsonResult(Ok(db.MuiVis));
        }
        [HttpGet]
        public JsonResult GetAllObject()
        {
            return new JsonResult(Ok(db.DoiTuongs));
        }
        [HttpGet]
        public JsonResult GetAllUnit()
        {
            return new JsonResult(Ok(db.DonViTinhs));
        }
        [HttpGet]
        public JsonResult GetAllCategory()
        {
            return new JsonResult(Ok(db.PhanLoais));
        }
        [HttpGet]
        public JsonResult GetAllDossage()
        {
            return new JsonResult(Ok(db.DonViTinhs));
        }
        [HttpGet]
        public JsonResult GetProductByID(int id)
        {
            return new JsonResult(Ok(db.SanPhams.FirstOrDefault(p => p.Id == id)));
        }

        [HttpGet]
        public JsonResult GetAllPersonProduct(int id)
        {
            
            var listPersonProduct = from c in db.QuanLyDoiTuongs.Where(a => a.IdsanPham == id)
                                    join d in db.DoiTuongs on c.IddoiTuong equals d.Id
                                    select new
                                    {
                                        IDDoiTuong = c.IddoiTuong,
                                        TenDoiTuong = d.Ten,
                                        ID = c.Id
                                    };
            return new JsonResult(Ok(listPersonProduct));
        }
        [HttpGet]
        public JsonResult GetAllFunctionByProduct(int id)
        {
            var listFunctionProduct = from c in db.QuanLyChiDinhs.Where(a => a.IdsanPham == id)
                                      join d in db.ChiDinhs on c.IdchiDinh equals d.Id
                                      select new
                                      {
                                          IDChiDinh = c.IdchiDinh,
                                          TenChiDinh = d.Ten,
                                          ID = c.Id
                                      };
            return new JsonResult(Ok(listFunctionProduct));
        }
        [HttpGet]
        public JsonResult GetAllFileByProduct(int id)
        {
           
            return new JsonResult(Ok(db.QuanLyHinhAnhs.Where(a => a.IdsanPham == id)));
        }
        [HttpGet]
        public JsonResult GetUnitById(int id)
        {
            return new JsonResult(Ok(db.DonViTinhs.FirstOrDefault(p => p.Id == id)));
        }
        [HttpGet]
        public JsonResult GetDossageById(int id)
        {
            return new JsonResult(Ok(db.DangBaoChes.FirstOrDefault(p => p.Id == id)));
        }
        [HttpGet]
        public JsonResult GetBrandByID(int id)
        {
            return new JsonResult(Ok(db.ThuongHieus.FirstOrDefault(p => p.Id == id)));
        }
        [HttpGet]
        public JsonResult GetAllPromotion(int page=1)
        {
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var temp = new
            {
                promotion=db.KhuyenMais.Take(take).OrderByDescending(p=>p.NgayKetThuc).Skip(skip),
                count=db.KhuyenMais.Count()-take
            };
            return new JsonResult(Ok(temp));
        }
        [HttpGet]
        public JsonResult GetPromotionByName(string name,int page=1)
        {
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var query=db.KhuyenMais.Where(p=>p.Ten.ToLower().Contains(name.ToLower())).OrderByDescending(p=>p.NgayKetThuc);
            var temp = new
            {
                promotion = query.Take(take).Skip(skip),
                count = query.Count() - take
            };
            return new JsonResult(Ok(temp));
        }
        [HttpGet]
        public JsonResult GetProductByIDPromotion(int id)
        {
            var temp = from a in db.ChiTietKhuyenMais.Where(p => p.IdkhuyenMai == id).Select(p => p.IdsanPham)
                       join b in db.SanPhams on a equals b.Id
                       select b;
            return new JsonResult(temp);
        }
       

        [HttpGet]
        public JsonResult GetProductCanPromotion(int page=1)
        {
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var query = from a in db.KhuyenMais.Where(p => p.NgayKetThuc > DateTime.Now)
                       join b in db.ChiTietKhuyenMais on a.Id equals b.IdkhuyenMai
                       select b.IdsanPham;
            var index = query.Distinct();
            var list =from p in db.SanPhams.Where(p => index.Contains(p.Id)==false)
                      select new
                      {
                          image = p.HinhAnhChinh,
                          name = p.Ten,
                          id=p.Id
                      };
            var temp = new
            {
                product = list.Take(take).Skip(skip),
                count = list.Count() - take
            };
            return new JsonResult(Ok(temp));
        }
        [HttpGet]
        public JsonResult GetProductCanPromotionByName(string name,int page = 1)
        {
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var query = from a in db.KhuyenMais.Where(p => p.NgayKetThuc > DateTime.Now)
                        join b in db.ChiTietKhuyenMais on a.Id equals b.IdkhuyenMai
                        select b.IdsanPham;
            var index = query.Distinct();
            var list =from p in db.SanPhams.Where(p => index.Contains(p.Id)==false&&p.Ten!.ToLower().Contains(name.ToLower()))
                      select new
                      {
                          image = p.HinhAnhChinh,
                          name = p.Ten,
                          id=p.Id
                      }; 
            var temp = new
            {
                product = list.Take(take).Skip(skip),
                count = list.Count() - take
            };
            return new JsonResult(Ok(temp));
        }
        [HttpGet]
        public JsonResult GetAllBillThisWeek(int page=1)
        {
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var currentDate = DateTime.Now;

            // Tìm ngày đầu tiên của tuần (thứ Hai)
            var firstDayOfWeek = currentDate.AddDays(-(int)currentDate.DayOfWeek + 1);
            var query =from bill in db.HoaDons.Where(p => p.Ngay>=firstDayOfWeek).OrderByDescending(p=>p.Ngay)
                       join cart in db.GioHangs on bill.IdgioHang equals cart.Id
                       join customer in db.KhachHangs on cart.IdkhachHang equals customer.Id
                       select new
                       {
                           TongTien=bill.TongTien,
                           GiamGiaTrucTiep=bill.GiamGiaTrucTiep,
                           Ngay=bill.Ngay,
                           TrangThai=bill.TrangThai,
                           id=bill.Id,
                           tenkhachhang=customer.Ten

                       };
            var temp = new
            {
                bill = query.Take(take).Skip(skip),
                count = query.Count() - take
            };
            
            return new JsonResult(Ok(temp));
        }
        [HttpGet]
        public JsonResult GetListBillFromDate(DateTime date,int page=1)
        {
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var query =from bill in db.HoaDons.Where(p => p.Ngay >= date)
                       join cart in db.GioHangs on bill.IdgioHang equals cart.Id
                       join customer in db.KhachHangs on cart.IdkhachHang equals customer.Id
                       select new
                       {
                           TongTien = bill.TongTien,
                           GiamGiaTrucTiep = bill.GiamGiaTrucTiep,
                           Ngay = bill.Ngay,
                           TrangThai = bill.TrangThai,
                           id = bill.Id,
                           tenkhachhang = customer.Ten

                       }; 
            var temp = new
            {
                bill = query.Take(take).Skip(skip),
                count = query.Count() - take
            };
            return new JsonResult(Ok(temp));
        }
        [HttpGet]
        public JsonResult GetBillByCustomerName(string name,int page=1)
        {
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var query = from customer in db.KhachHangs.Where(p => p.Ten.ToLower().Contains(name.ToLower()))
                        join cart in db.GioHangs on customer.Id equals cart.IdkhachHang
                        join bill in db.HoaDons on cart.Id equals bill.IdgioHang
                        select new
                        {
                            TongTien = bill.TongTien,
                            GiamGiaTrucTiep = bill.GiamGiaTrucTiep,
                            Ngay = bill.Ngay,
                            TrangThai = bill.TrangThai,
                            id = bill.Id,
                            tenkhachhang = customer.Ten

                        };
            var temp = new
            {
                bill = query.OrderByDescending(p => p.Ngay).Take(take).Skip(skip),
                count = query.Count() - take
            };
            return new JsonResult(Ok(temp));
        }
        [HttpPost]
        public JsonResult UpdateStateBill(int idbill,string state)
        {
            var temp = db.HoaDons.FirstOrDefault(p => p.Id == idbill);
            temp.TrangThai = state;
            db.SaveChanges();
            return new JsonResult(Ok("Success"));
        }
        [HttpGet]
        public JsonResult GetListUser(int page=1)
        {
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var temp = new
            {
                user = db.KhachHangs.Take(take).Skip(skip),
                count = db.KhachHangs.Count() - take
            };
            return new JsonResult(Ok(temp));
        }
        [HttpGet]
        public JsonResult GetListUserByName(string name,int page=1)
        {
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var query = (from u in db.KhachHangs.Where(p => p.Ten.ToLower().Contains(name.ToLower()))
                        join c in db.GioHangs on u.Id equals c.IdkhachHang
                        join b in db.HoaDons.OrderByDescending(p => p.Ngay) on c.Id equals b.IdgioHang
                        select u).Distinct();
            var temp = new
            {
                user = query.Take(take).Skip(skip),
                count = query.Count() - take
            };
            return new JsonResult(Ok(temp));
        }
        [HttpGet]
        public JsonResult GetListUserByDate(DateTime date,int page=1)
        {
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var query = (from u in db.KhachHangs
                         join c in db.GioHangs on u.Id equals c.IdkhachHang
                         join b in db.HoaDons.Where(p=>p.Ngay>=date).OrderByDescending(p => p.Ngay) on c.Id equals b.IdgioHang
                         select u).Distinct();
            var temp = new
            {
                user = query.Take(take).Skip(skip),
                count = query.Count() - take
            };
            return new JsonResult(Ok(temp));
        }
        [HttpGet]
        public JsonResult DataDrawChart()
        {
            int curmonth = DateTime.Now.Month;
            List<int> list = new List<int>();
            for (int i = 1; i <= curmonth; i++) list.Add(i);
            
            var query = db.HoaDons.GroupBy(b => b.Ngay!.Value.Month).Select(g => new
            {
                month = g.Key,
                revenue = g.Sum(c => c.TongTien)
            }).ToList();
            var result = from m in list
                         join q in query on m equals q.month into t
                         from q in t.DefaultIfEmpty()
                         select new
                         {
                            month=m,
                            revenue=(q==null)?0:q.revenue
                         };
            return new JsonResult(Ok(result));
            

        }
        [HttpGet]
        public JsonResult GetTopSellProduct(int page=1)
        {
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var query = db.ChiTietHoaDons.GroupBy(d => d.IdsanPham).Select(g => new
            {
                idproduct=g.Key,
                quantity=g.Sum(c=>c.Soluong)
            }).ToList().OrderByDescending(p=>p.quantity);
            var result = from q in query
                         join p in db.SanPhams on q.idproduct equals p.Id
                         select new
                         {
                             image = p.HinhAnhChinh,
                             id = p.Id,
                             name = p.Ten,
                             quantity = q.quantity
                         };
            var temp = new
            {
                product = result.Take(take).Skip(skip),
                count = result.Count() - take
            };
            return new JsonResult(Ok(temp));
        }

        #endregion
    }
}
