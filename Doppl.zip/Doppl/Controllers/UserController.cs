﻿using Doppl.Models;
using Microsoft.AspNetCore.Mvc;
using System.Xml.Linq;

namespace Doppl.Controllers
{
    public class UserController : Controller
    {
        private int numpage = 1;
        public static int iduser = 1;
        public static int idcart = 2;
        QuanLyThuocContext db = new QuanLyThuocContext();
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult ViewHomePage()
        {
            ViewBag.iduser = iduser;
            ViewBag.idcart = idcart;
            return View();
        }
        public IActionResult DetailProductUser(int id=24)
        {
            ViewBag.iduser = iduser;
            ViewBag.idcart = idcart;

            return View(db.SanPhams.FirstOrDefault(p=>p.Id==id));
        }
        public IActionResult DetailBrandUser(int id = 1)
        {
            ViewBag.iduser = iduser;
            ViewBag.idcart = idcart;

            return View(db.ThuongHieus.FirstOrDefault(p=>p.Id==id));
        }
        public IActionResult ViewCart(int iduser=1)
        {
            ViewBag.iduser = iduser;
            ViewBag.idcart = idcart;

            return View(db.GioHangs.FirstOrDefault(p=>p.IdkhachHang==iduser)!.Id);
        }
        public IActionResult ViewListBill(int idcart=2)
        {
            ViewBag.iduser = iduser;
            ViewBag.idcart = idcart;


            return View(idcart);
        }
        [HttpGet]
        public IActionResult SignUpUser()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SignUpUser(KhachHang customer)
        {
            db.KhachHangs.Add(customer);
            db.SaveChanges();
            return RedirectToAction("LoginUser");
        }
        [HttpGet]
        public IActionResult EditUser(int iduser=1)
        {
            ViewBag.iduser = iduser;
            ViewBag.idcart = idcart;

            return View(db.KhachHangs.FirstOrDefault(p=>p.Id==iduser));
        }
        [HttpPost]
        public IActionResult EditUser(KhachHang user)
        {
            var original = db.KhachHangs.FirstOrDefault(p => p.Id == user.Id);
            original.Ten = user.Ten;
            original.DiaChi = user.DiaChi;
            original.SoDienThoai = user.SoDienThoai;
            original.NgaySinh = user.NgaySinh;
            original.TenDangNhap = user.TenDangNhap;
            original.MatKhau = user.MatKhau;
            db.SaveChanges();
            return View(original);
        }
        public IActionResult ShowProfileUser(int iduser = 1)
        {
            ViewBag.iduser = iduser;
            ViewBag.idcart = idcart;
            return View(db.KhachHangs.FirstOrDefault(p=>p.Id==iduser));
        }
        #region JSon
        [HttpGet]
        public JsonResult GetAllProductWithPromotion(int page=1)
        {
           
            var query = from s in db.LoHangs.OrderBy(p=>p.NgayHetHan)
                        where s.SoluongCon > 0&&s.NgayHetHan>DateTime.Now
                        
                        group s by s.IdsanPham into g
                        
                        select new
                        {
                            idProduct = g.Key,
                            quantity = g.First().SoluongCon,
                            cost=g.First().GiaBan,
                            price=g.First().GiaVon
                        };
            var getpromotions = from p in db.KhuyenMais.Where(p => p.NgayKetThuc > DateTime.Now)
                                join d in db.ChiTietKhuyenMais on p.Id equals d.IdkhuyenMai
                                select new
                                {
                                    idProduct = d.IdsanPham,
                                    percenpromotion = p.TiLeGiamGia,
                                    
                                };
            var detailproduct = from product in query
                                join promotion in getpromotions on product.idProduct equals promotion.idProduct
                                into t
                                from promotion in t.DefaultIfEmpty()
                                select new
                                {
                                    idproduct = product.idProduct,
                                    salepercen = (promotion == null) ? 0 : promotion.percenpromotion,
                                    cost=product.cost,
                                    price=product.price,
                                    quantity=product.quantity
                                };
            var containproduct = from p in db.SanPhams
                                 join u in db.DonViTinhs on p.IddonViTinh equals u.Id
                                 join d in db.DangBaoChes on p.IddangBaoChe equals d.Id
                                 join b in db.ThuongHieus on p.IdthuongHieu equals b.Id
                                 select new
                                 {
                                     id = p.Id,
                                     idbrand = p.IdthuongHieu,
                                     brandname = b.Ten,
                                     idskin = p.IdloaiDa,
                                     idtaste = p.IdmuiVi,
                                     name = p.Ten,
                                     idunit = p.IddonViTinh,
                                     unitname = u.Ten,
                                     mainimage=p.HinhAnhChinh,
                                     specipication=p.QuyCach,
                                     
                                 };

            var temp = from d in detailproduct
                       join p in containproduct on d.idproduct equals p.id
                       select new
                       {
                                   product = p,
                                   cost = d.cost,
                                   price = d.price,
                                   promotionpercen = d.salepercen,
                                   pricepromotion = (1 - (decimal)0.01 * d.salepercen) * d.price,
                                   quantity=d.quantity
                       };
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var result = new
            {
                list=temp.Take(take).Skip(skip),
                count=temp.Count()-take
            };
            return new JsonResult(Ok(result));
        }
        [HttpGet]
        public JsonResult GetAllProductWithPromotionByName(string name,int page=1)
        {
            var query = from s in db.LoHangs.OrderBy(p=>p.NgayHetHan)
                        where s.SoluongCon > 0 && s.NgayHetHan > DateTime.Now
                        group s by s.IdsanPham into g
                        select new
                        {
                            idProduct = g.Key,
                            quantity = g.First().SoluongCon,
                            cost = g.First().GiaBan,
                            price = g.First().GiaVon
                        };
            var getpromotions = from p in db.KhuyenMais.Where(p => p.NgayKetThuc > DateTime.Now)
                                join d in db.ChiTietKhuyenMais on p.Id equals d.IdkhuyenMai
                                select new
                                {
                                    idProduct = d.IdsanPham,
                                    percenpromotion = p.TiLeGiamGia,

                                };
            var detailproduct = from product in query
                                join promotion in getpromotions on product.idProduct equals promotion.idProduct
                                into t
                                from promotion in t.DefaultIfEmpty()
                                select new
                                {
                                    idproduct = product.idProduct,
                                    salepercen = (promotion == null) ? 0 : promotion.percenpromotion,
                                    cost = product.cost,
                                    price = product.price,
                                    quantity = product.quantity
                                };
            var containproduct = from p in db.SanPhams.Where(p=>p.Ten.ToLower().Contains(name.ToLower()))
                                 join u in db.DonViTinhs on p.IddonViTinh equals u.Id
                                 join d in db.DangBaoChes on p.IddangBaoChe equals d.Id
                                 join b in db.ThuongHieus on p.IdthuongHieu equals b.Id
                                 select new
                                 {
                                     id = p.Id,
                                     idbrand = p.IdthuongHieu,
                                     brandname = b.Ten,
                                     idskin = p.IdloaiDa,
                                     idtaste = p.IdmuiVi,
                                     name = p.Ten,
                                     idunit = p.IddonViTinh,
                                     unitname = u.Ten,
                                     mainimage = p.HinhAnhChinh,
                                     specipication = p.QuyCach,

                                 };

            var temp = from d in detailproduct
                       join p in containproduct on d.idproduct equals p.id
                       select new
                       {
                           product = p,
                           cost = d.cost,
                           price = d.price,
                           promotionpercen = d.salepercen,
                           pricepromotion = (1 - (decimal)0.01 * d.salepercen) * d.price,
                           quantity = d.quantity
                       };
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var result = new
            {
                list = temp.Take(take).Skip(skip),
                count = temp.Count() - take
            };
            return new JsonResult(Ok(result));
        }
        [HttpPost]
        public JsonResult GetAllProductWithPromotionByIDFunction(int[] ids,int page=1)
        {
            var query = from s in db.LoHangs.OrderBy(p => p.NgayHetHan)
                        where s.SoluongCon > 0 && s.NgayHetHan > DateTime.Now
                        group s by s.IdsanPham into g
                        select new
                        {
                            idProduct = g.Key,
                            quantity = g.First().SoluongCon,
                            cost = g.First().GiaBan,
                            price = g.First().GiaVon
                        };
            var getpromotions = from p in db.KhuyenMais.Where(p => p.NgayKetThuc > DateTime.Now)
                                join d in db.ChiTietKhuyenMais on p.Id equals d.IdkhuyenMai
                                select new
                                {
                                    idProduct = d.IdsanPham,
                                    percenpromotion = p.TiLeGiamGia,

                                };
            var detailproduct = from product in query
                                join promotion in getpromotions on product.idProduct equals promotion.idProduct
                                into t
                                from promotion in t.DefaultIfEmpty()
                                select new
                                {
                                    idproduct = product.idProduct,
                                    salepercen = (promotion == null) ? 0 : promotion.percenpromotion,
                                    cost = product.cost,
                                    price = product.price,
                                    quantity = product.quantity
                                };
            var uniqueID = db.QuanLyChiDinhs.Where(p => ids.Contains((int)p.IdchiDinh!)).Select(p => p.IdsanPham).Distinct();
            var containproduct = from p in db.SanPhams.Where(p => uniqueID.Contains(p.Id))
                                 join u in db.DonViTinhs on p.IddonViTinh equals u.Id
                                 join d in db.DangBaoChes on p.IddangBaoChe equals d.Id
                                 join b in db.ThuongHieus on p.IdthuongHieu equals b.Id
                                 select new
                                 {
                                     id = p.Id,
                                     idbrand = p.IdthuongHieu,
                                     brandname = b.Ten,
                                     idskin = p.IdloaiDa,
                                     idtaste = p.IdmuiVi,
                                     name = p.Ten,
                                     idunit = p.IddonViTinh,
                                     unitname = u.Ten,
                                     mainimage = p.HinhAnhChinh,
                                     specipication = p.QuyCach,

                                 };

            var temp = from d in detailproduct
                       join p in containproduct on d.idproduct equals p.id
                       select new
                       {
                           product = p,
                           cost = d.cost,
                           price = d.price,
                           promotionpercen = d.salepercen,
                           pricepromotion = (1 - (decimal)0.01 * d.salepercen) * d.price,
                           quantity = d.quantity
                       };
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var result = new
            {
                list = temp.Take(take).Skip(skip),
                count = temp.Count() - take
            };
            return new JsonResult(Ok(result));
        }
        [HttpPost]
        public JsonResult GetAllProductWithPromotionByIDObject(int[] ids, int page = 1)
        {
            var query = from s in db.LoHangs.OrderBy(p=>p.NgayHetHan)
                        where s.SoluongCon > 0 && s.NgayHetHan > DateTime.Now
                        group s by s.IdsanPham into g
                        select new
                        {
                            idProduct = g.Key,
                            quantity = g.First().SoluongCon,
                            cost = g.First().GiaBan,
                            price = g.First().GiaVon
                        };
            var getpromotions = from p in db.KhuyenMais.Where(p => p.NgayKetThuc > DateTime.Now)
                                join d in db.ChiTietKhuyenMais on p.Id equals d.IdkhuyenMai
                                select new
                                {
                                    idProduct = d.IdsanPham,
                                    percenpromotion = p.TiLeGiamGia,

                                };
            var detailproduct = from product in query
                                join promotion in getpromotions on product.idProduct equals promotion.idProduct
                                into t
                                from promotion in t.DefaultIfEmpty()
                                select new
                                {
                                    idproduct = product.idProduct,
                                    salepercen = (promotion == null) ? 0 : promotion.percenpromotion,
                                    cost = product.cost,
                                    price = product.price,
                                    quantity = product.quantity
                                };
            var uniqueID = db.QuanLyDoiTuongs.Where(p => ids.Contains((int)p.IddoiTuong!)).Select(p => p.IdsanPham).Distinct();
            var containproduct = from p in db.SanPhams.Where(p => uniqueID.Contains(p.Id))
                                 join u in db.DonViTinhs on p.IddonViTinh equals u.Id
                                 join d in db.DangBaoChes on p.IddangBaoChe equals d.Id
                                 join b in db.ThuongHieus on p.IdthuongHieu equals b.Id
                                 select new
                                 {
                                     id = p.Id,
                                     idbrand = p.IdthuongHieu,
                                     brandname = b.Ten,
                                     idskin = p.IdloaiDa,
                                     idtaste = p.IdmuiVi,
                                     name = p.Ten,
                                     idunit = p.IddonViTinh,
                                     unitname = u.Ten,
                                     mainimage = p.HinhAnhChinh,
                                     specipication = p.QuyCach,

                                 };

            var temp = from d in detailproduct
                       join p in containproduct on d.idproduct equals p.id
                       select new
                       {
                           product = p,
                           cost = d.cost,
                           price = d.price,
                           promotionpercen = d.salepercen,
                           pricepromotion = (1 - (decimal)0.01 * d.salepercen) * d.price,
                           quantity = d.quantity
                       };
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var result = new
            {
                list = temp.Take(take).Skip(skip),
                count = temp.Count() - take
            };
            return new JsonResult(Ok(result));
        }

        [HttpGet]
        public JsonResult GetAllProductWithPromotionByBrandID(int id,int page=1)
        {
            var query = from s in db.LoHangs.OrderBy(p => p.NgayHetHan)
                        where s.SoluongCon > 0&&s.NgayHetHan>DateTime.Now
                        group s by s.IdsanPham into g
                        select new
                        {
                            idProduct = g.Key,
                            quantity = g.First().SoluongCon,
                            cost = g.First().GiaBan,
                            price = g.First().GiaVon
                        };
            var getpromotions = from p in db.KhuyenMais.Where(p => p.NgayKetThuc > DateTime.Now)
                                join d in db.ChiTietKhuyenMais on p.Id equals d.IdkhuyenMai
                                select new
                                {
                                    idProduct = d.IdsanPham,
                                    percenpromotion = p.TiLeGiamGia,

                                };
            var detailproduct = from product in query
                                join promotion in getpromotions on product.idProduct equals promotion.idProduct
                                into t
                                from promotion in t.DefaultIfEmpty()
                                select new
                                {
                                    idproduct = product.idProduct,
                                    salepercen = (promotion == null) ? 0 : promotion.percenpromotion,
                                    cost = product.cost,
                                    price = product.price
                                };
            var containproduct = from p in db.SanPhams.Where(p=>p.IdthuongHieu==id)
                                 join u in db.DonViTinhs on p.IddonViTinh equals u.Id
                                 join d in db.DangBaoChes on p.IddangBaoChe equals d.Id
                                 join b in db.ThuongHieus on p.IdthuongHieu equals b.Id
                                 
                                 select new
                                 {
                                     id = p.Id,
                                     idbrand = p.IdthuongHieu,
                                     brandname = b.Ten,
                                     idskin = p.IdloaiDa,
                                     idtaste = p.IdmuiVi,
                                     name = p.Ten,
                                     idunit = p.IddonViTinh,
                                     unitname = u.Ten,
                                     mainimage = p.HinhAnhChinh,
                                     specipication = p.QuyCach,

                                 };

            var temp = from d in detailproduct
                       join p in containproduct on d.idproduct equals p.id
                       select new
                       {
                           product = p,
                           cost = d.cost,
                           price = d.price,
                           promotionpercen = d.salepercen,
                           pricepromotion = (1 - (decimal)0.01 * d.salepercen) * d.price
                       };
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var result = new
            {
                list = temp.Take(take).Skip(skip),
                count = temp.Count() - take
            };
            return new JsonResult(Ok(result));
        }
        [HttpGet]
        public JsonResult GetAllProductWithPromotionBySkinID(int id, int page = 1)
        {
            var query = from s in db.LoHangs.OrderBy(p => p.NgayHetHan)
                        where s.SoluongCon > 0 && s.NgayHetHan > DateTime.Now
                        group s by s.IdsanPham into g
                        select new
                        {
                            idProduct = g.Key,
                            quantity = g.First().SoluongCon,
                            cost = g.First().GiaBan,
                            price = g.First().GiaVon
                        };
            var getpromotions = from p in db.KhuyenMais.Where(p => p.NgayKetThuc > DateTime.Now)
                                join d in db.ChiTietKhuyenMais on p.Id equals d.IdkhuyenMai
                                select new
                                {
                                    idProduct = d.IdsanPham,
                                    percenpromotion = p.TiLeGiamGia,

                                };
            var detailproduct = from product in query
                                join promotion in getpromotions on product.idProduct equals promotion.idProduct
                                into t
                                from promotion in t.DefaultIfEmpty()
                                select new
                                {
                                    idproduct = product.idProduct,
                                    salepercen = (promotion == null) ? 0 : promotion.percenpromotion,
                                    cost = product.cost,
                                    price = product.price
                                };
            var containproduct = from p in db.SanPhams.Where(p => p.IdloaiDa == id)
                                 join u in db.DonViTinhs on p.IddonViTinh equals u.Id
                                 join d in db.DangBaoChes on p.IddangBaoChe equals d.Id
                                 join b in db.ThuongHieus on p.IdthuongHieu equals b.Id

                                 select new
                                 {
                                     id = p.Id,
                                     idbrand = p.IdthuongHieu,
                                     brandname = b.Ten,
                                     idskin = p.IdloaiDa,
                                     idtaste = p.IdmuiVi,
                                     name = p.Ten,
                                     idunit = p.IddonViTinh,
                                     unitname = u.Ten,
                                     mainimage = p.HinhAnhChinh,
                                     specipication = p.QuyCach,

                                 };

            var temp = from d in detailproduct
                       join p in containproduct on d.idproduct equals p.id
                       select new
                       {
                           product = p,
                           cost = d.cost,
                           price = d.price,
                           promotionpercen = d.salepercen,
                           pricepromotion = (1 - (decimal)0.01 * d.salepercen) * d.price
                       };
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var result = new
            {
                list = temp.Take(take).Skip(skip),
                count = temp.Count() - take
            };
            return new JsonResult(Ok(result));
        }
        [HttpGet]
        public JsonResult GetAllProductWithPromotionByTasteID(int id, int page = 1)
        {
            var query = from s in db.LoHangs.OrderBy(p=>p.NgayHetHan)
                        where s.SoluongCon > 0 && s.NgayHetHan > DateTime.Now
                        group s by s.IdsanPham into g
                        select new
                        {
                            idProduct = g.Key,
                            quantity = g.First().SoluongCon,
                            cost = g.First().GiaBan,
                            price = g.First().GiaVon
                        };
            var getpromotions = from p in db.KhuyenMais.Where(p => p.NgayKetThuc > DateTime.Now)
                                join d in db.ChiTietKhuyenMais on p.Id equals d.IdkhuyenMai
                                select new
                                {
                                    idProduct = d.IdsanPham,
                                    percenpromotion = p.TiLeGiamGia,

                                };
            var detailproduct = from product in query
                                join promotion in getpromotions on product.idProduct equals promotion.idProduct
                                into t
                                from promotion in t.DefaultIfEmpty()
                                select new
                                {
                                    idproduct = product.idProduct,
                                    salepercen = (promotion == null) ? 0 : promotion.percenpromotion,
                                    cost = product.cost,
                                    price = product.price
                                };
            var containproduct = from p in db.SanPhams.Where(p => p.IdmuiVi == id)
                                 join u in db.DonViTinhs on p.IddonViTinh equals u.Id
                                 join d in db.DangBaoChes on p.IddangBaoChe equals d.Id
                                 join b in db.ThuongHieus on p.IdthuongHieu equals b.Id

                                 select new
                                 {
                                     id = p.Id,
                                     idbrand = p.IdthuongHieu,
                                     brandname = b.Ten,
                                     idskin = p.IdloaiDa,
                                     idtaste = p.IdmuiVi,
                                     name = p.Ten,
                                     idunit = p.IddonViTinh,
                                     unitname = u.Ten,
                                     mainimage = p.HinhAnhChinh,
                                     specipication = p.QuyCach,

                                 };

            var temp = from d in detailproduct
                       join p in containproduct on d.idproduct equals p.id
                       select new
                       {
                           product = p,
                           cost = d.cost,
                           price = d.price,
                           promotionpercen = d.salepercen,
                           pricepromotion = (1 - (decimal)0.01 * d.salepercen) * d.price
                       };
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var result = new
            {
                list = temp.Take(take).Skip(skip),
                count = temp.Count() - take
            };
            return new JsonResult(Ok(result));
        }
        [HttpGet]
        public JsonResult GetNumberPriceCostProduct(int id)
        {

            var query = from s in db.LoHangs
                        where s.SoluongCon > 0&&s.NgayHetHan>DateTime.Now
                        group s by s.IdsanPham into g
                        select new
                        {
                            idProduct = g.Key,
                            quantity = g.First().SoluongCon,
                            cost = g.First().GiaBan,
                            price = g.First().GiaVon
                        };
            var getpromotions = from p in db.KhuyenMais.Where(p => p.NgayKetThuc > DateTime.Now)
                                join d in db.ChiTietKhuyenMais on p.Id equals d.IdkhuyenMai
                                where d.IdsanPham==id
                                select new
                                
                                {
                                    idProduct = d.IdsanPham,
                                    percenpromotion = p.TiLeGiamGia,

                                };
            var detailproduct = from product in query.Where(p=>p.idProduct==id)
                                join promotion in getpromotions on product.idProduct equals promotion.idProduct
                                into t
                                from promotion in t.DefaultIfEmpty()
                                select new
                                {
                                    idproduct = product.idProduct,
                                    salepercen = (promotion == null) ? 0 : promotion.percenpromotion,
                                    cost = product.cost,
                                    price = product.price,
                                    quantity=product.quantity
                                };
            var containproduct = from p in db.SanPhams
                                 join u in db.DonViTinhs on p.IddonViTinh equals u.Id
                                 join d in db.DangBaoChes on p.IddangBaoChe equals d.Id
                                 join b in db.ThuongHieus on p.IdthuongHieu equals b.Id
                                 where p.Id==id
                                 select new
                                 {
                                     id = p.Id,
                                     idbrand = p.IdthuongHieu,
                                     brandname = b.Ten,
                                     idskin = p.IdloaiDa,
                                     idtaste = p.IdmuiVi,
                                     name = p.Ten,
                                     idunit = p.IddonViTinh,
                                     unitname = u.Ten,
                                     mainimage = p.HinhAnhChinh,
                                     specipication = p.QuyCach,

                                 };

            var temp = from d in detailproduct
                       join p in containproduct on d.idproduct equals p.id
                       select new
                       {
                           product = p,
                           cost = d.cost,
                           price = d.price,
                           promotionpercen = d.salepercen,
                           pricepromotion = (1 - (decimal)0.01 * d.salepercen) * d.price,
                           quantity=d.quantity
                       };
            return new JsonResult(Ok(temp));

        }
        [HttpPost]
        public JsonResult AddProductIntoCart(int idproduct,int quantity,int iduser=1)
        {
            
            var cart = db.GioHangs.FirstOrDefault(p => p.IdkhachHang == iduser);
            if (db.ChiTietGioHangs.FirstOrDefault(p=>p.IdgioHang==cart.Id&&p.IdsanPham==idproduct) == null)
            {
                db.ChiTietGioHangs.Add(new ChiTietGioHang { IdgioHang = cart.Id, IdsanPham = idproduct, Soluong = quantity });
                
                db.SaveChanges();
                return new JsonResult(Ok("Success"));
            }

            return new JsonResult(Ok("Failed"));
        }
        [HttpPost]
        public JsonResult GetProductInCartByListID(int[] ids)
        {
            var query = from s in db.LoHangs
                        where s.SoluongCon > 0 &&s.NgayHetHan>DateTime.Now
                        group s by s.IdsanPham into g
                        select new
                        {
                            idProduct = g.Key,
                            quantity = g.First().SoluongCon,
                            cost = g.First().GiaBan,
                            price = g.First().GiaVon
                        };
            var getpromotions = from p in db.KhuyenMais.Where(p => p.NgayKetThuc > DateTime.Now)
                                join d in db.ChiTietKhuyenMais on p.Id equals d.IdkhuyenMai
                                select new
                                {
                                    idProduct = d.IdsanPham,
                                    percenpromotion = p.TiLeGiamGia,

                                };
            var detailproduct = from product in query
                                join promotion in getpromotions on product.idProduct equals promotion.idProduct
                                into t
                                from promotion in t.DefaultIfEmpty()
                                select new
                                {
                                    idproduct = product.idProduct,
                                    salepercen = (promotion == null) ? 0 : promotion.percenpromotion,
                                    cost = product.cost,
                                    price = product.price,
                                    quantity=product.quantity
                                };
            var containproduct = from p in db.SanPhams.Where(p=>ids.Contains(p.Id))
                                 join u in db.DonViTinhs on p.IddonViTinh equals u.Id
                                 join d in db.DangBaoChes on p.IddangBaoChe equals d.Id
                                 join b in db.ThuongHieus on p.IdthuongHieu equals b.Id

                                 select new
                                 {
                                     id = p.Id,
                                     idbrand = p.IdthuongHieu,
                                     brandname = b.Ten,
                                     idskin = p.IdloaiDa,
                                     idtaste = p.IdmuiVi,
                                     name = p.Ten,
                                     idunit = p.IddonViTinh,
                                     unitname = u.Ten,
                                     mainimage = p.HinhAnhChinh,
                                     specipication = p.QuyCach,

                                 };

            var temp = from d in detailproduct
                       join p in containproduct on d.idproduct equals p.id
                       select new
                       {
                           product = p,
                           cost = d.cost,
                           price = d.price,
                           promotionpercen = d.salepercen,
                           pricepromotion = (1 - (decimal)0.01 * d.salepercen) * d.price,
                           quantity=d.quantity
                       };
            return new JsonResult(Ok(temp));
        }
        [HttpGet]
        public JsonResult GetAllDetailCartByID(int idcart)
        {
            return new JsonResult(Ok(db.ChiTietGioHangs.Where(p => p.IdgioHang == idcart)));
        }
        [HttpPost]
        public JsonResult DeleteCartItemDetail(int iddetail)
        {
            var temp = db.ChiTietGioHangs.FirstOrDefault(p => p.Id == iddetail);
            db.ChiTietGioHangs.Remove(temp);
            db.SaveChanges();
            return new JsonResult(Ok("Ok"));
        }
        [HttpPost]
        public JsonResult CreateBill(int[] idproduct, int[] quantity,int idcart,int price,int promotion)
        {
            var query = from s in db.LoHangs
                        where s.SoluongCon > 0 && s.NgayHetHan > DateTime.Now
                        group s by s.IdsanPham into g
                        select new
                        {
                            idProduct = g.Key,
                            idshipment = g.First().Id,

                        };
            for (int i=0;i<idproduct.Count();i++)
            {
                var shipment = query.FirstOrDefault(p => p.idProduct == idproduct[i]);
                if (shipment!=null)
                {
                    int idshipment = shipment.idshipment;
                    var original = db.LoHangs.FirstOrDefault(p => p.Id == idshipment);
                    original!.SoluongCon -= quantity[i];
                    db.SaveChanges();
                }
            }
            db.HoaDons.Add(new HoaDon { TongTien = promotion, GiamGiaTrucTiep = price - promotion, GiamGiaVoucher = 0, TietKiem = price - promotion, TamTinh = promotion, Ngay = DateTime.Now, TrangThai = "Đang xử lý", IdgioHang = idcart });
            db.SaveChanges();
            int idbill = db.HoaDons.Max(p => p.Id);
            for (int i=0;i<idproduct.Count();i++)
            {
                db.ChiTietHoaDons.Add(new ChiTietHoaDon { IdhoaDon = idbill, IdsanPham = idproduct[i], Soluong = quantity[i] });    
            }
            db.SaveChanges();
            return new JsonResult(Ok("Success"));
        }
        [HttpGet]
        public JsonResult GetListBillByIDCart(int idcart,int page=1)
        {
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var query = db.HoaDons.Where(p => p.IdgioHang == idcart).OrderByDescending(p => p.Ngay);
            var temp = new
            {
                bill=query.Take(take).Skip(skip),
                count=query.Count()-take
            };
            return new JsonResult(Ok(temp)) ;
        }
        [HttpGet]
        public JsonResult GetListBillByIDCartAndDate(int idcart,DateTime date,int page=1)
        {
            int take = page * numpage;
            int skip = (page - 1) * numpage;
            var query = db.HoaDons.Where(p => p.IdgioHang == idcart&&p.Ngay>=date).OrderByDescending(p => p.Ngay);
            var temp = new
            {
                bill = query.Take(take).Skip(skip),
                count = query.Count() - take
            };
            return new JsonResult(Ok(temp));
        }
        [HttpGet]
        public JsonResult GetDetailBillByID(int idbill)
        {
            var temp = from d in db.ChiTietHoaDons.Where(p => p.IdhoaDon == idbill)
                       join p in db.SanPhams on d.IdsanPham equals p.Id
                       select new
                       {
                           image = p.HinhAnhChinh,
                           name = p.Ten,
                           quantity = d.Soluong
                       };
            return new JsonResult(Ok(temp));
        }
        [HttpGet]
        public IActionResult LoginUser()
        {

            return View(true);
        }
        [HttpPost]
        public IActionResult LoginUser(string username,string password)
        {
            var find = db.KhachHangs.FirstOrDefault(p =>p.TenDangNhap==username&&p.MatKhau==password);
            if (find==null)
            {
                return View(false);
            }
            iduser = find.Id;
            
            idcart = db.GioHangs.FirstOrDefault(p => p.IdkhachHang == iduser).Id;
            
            return RedirectToAction("ViewHomePage");
        }
        public IActionResult SelecRow()
        {
            return View();
        }
        #endregion

    }
}
